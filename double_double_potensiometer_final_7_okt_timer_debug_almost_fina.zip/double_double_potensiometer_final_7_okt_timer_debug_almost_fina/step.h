unsigned long interval= 1; // the time we need to wait
unsigned long previousMillis=0; // millis() returns an unsigned long.
unsigned long previousMillis1=0;
int j;


void steponeanticlockwise(){
  for (int i = 0; i < (stepsPerRevolution/8) ; i++) {   
  unsigned long currentMillis = millis(); // grab current time
 
 if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
    
    if (j==0){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    }

    if (j==1){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    
    }

    if (j==2){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);    
    }
    
    if (j==3){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    }

    if (j == 4){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    }

    if (j == 5){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    }

    if (j== 6){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    }
    if (j == 7){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    }
    if (j == 8){
    a = a-1;
      //b = b-0; 
      j=0;
    
    }
    
  }
}

void steponeclockwise(){
  for (int i = 0; i < (stepsPerRevolution/8); i++) {
  unsigned long currentMillis = millis(); // grab current time
   if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
 if (j == 0){  
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    //1
  }
 if (j == 1){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);

    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    //2
  }

 if (j == 2){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    //3
  }
 if (j == 3){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    //4
 }
 if (j == 4){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
  }
if (j == 5){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    //6
  }
if (j == 6){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
     //7
  }
if (j == 7){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
      //8
  }
  if (j == 8){
      //8
      a = a+1;
//b = b-0; 
      j = 0;
     
  }
 
}
 
}

void steptwoanticlockwise(){
  for (int i = 0; i < (stepsPerRevolution/8) ; i++) {
   unsigned long currentMillis = millis(); // grab current time
   if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
  if (j == 0){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 1){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 2){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 3){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 4){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }

  if (j == 5){ 
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }

  if (j == 6){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  } 

  if (j == 7){  
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }

  if (j == 8){
    j = 0;
    b = b-1;
  }
}
}


void steptwoclockwise(){
  for (int i = 0; i < (stepsPerRevolution/8) ; i++) {
   unsigned long currentMillis = millis(); // grab current time
   if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
  if (j == 0){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 1){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 2){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 3){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }
  if (j == 4){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }

  if (j == 5){ 
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }

  if (j == 6){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  } 

  if (j == 7){  
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
  }

  if (j == 8){
    j = 0;
    b = b+1;
  }
}
}

void steponeclockwisesteptwoclockwise(){
  for (int i = 0; i < (stepsPerRevolution/8) ; i++) {
    unsigned long currentMillis = millis(); // grab current time
   if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
 if (j == 0){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
 }//1
 if (j == 1){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
 }//2
 if (j == 2){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
}//3
 if (j == 3){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
}//4
 if (j == 4){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
 }//5
  if (j == 5) {
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
 }//6
  if (j == 6){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
  } //7

   if (j == 7){ 
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
   } //8
   if (j == 8){
    a = a+1;
    b = b+1;
    j=0;
    
   }
   
}

}
void steponeanticlockwisesteptwoanticlockwise(){
  for (int i = 0; i < (stepsPerRevolution/8) ; i++) {
    unsigned long currentMillis = millis(); // grab current time
   if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
 if (j == 0){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
 }//1
if (j == 1){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
}//2

if (j == 2){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
}//3
if (j == 3){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
}//4

if (j == 4){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
}//5
if (j == 5){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
}//6

if (j == 6){
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
}//7

if (j == 7){
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
}//8

if (j == 8){
a = a-1;
b = b-1;
  j = 0;
  
}

}

}
void steponeclockwisesteptwoanticlockwise(){
  for (int i = 0; i < (stepsPerRevolution/8); i++) {
   unsigned long currentMillis = millis(); // grab current time
   if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
    
   if (j ==0){ 
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
   }//1
   if (j == 1){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
   }//2
    if (j == 2){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    }//3

    if (j == 3){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
    }//4

    if (j == 4){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
    }//5

    if (j == 5){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    }//6

    if (j == 6){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    } //7

    if (j == 7){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
    }  //8

    if (j == 8){
     a = a+1;
 b = b-1;
      j = 0;
      
    }
    
  }
  
}



void steponeanticlockwisesteptwoclockwise(){
  for (int i = 0; i < (stepsPerRevolution/8) ; i++) {
    unsigned long currentMillis = millis(); // grab current time
   if ((unsigned long)(currentMillis - previousMillis) >= interval) {
   j++;
   // save the "current" time
   previousMillis = millis();
 }
 
 if(j == 0){ 
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
 }
 
 if (j == 1){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
 }
 
 if (j == 2){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, HIGH);
 }

 if (j == 3){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, HIGH);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
 }
 if (j == 4){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, LOW);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, HIGH);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
 }
 if (j == 5){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, HIGH);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, LOW);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
 }
 if (j == 6){
    digitalWrite(A1, LOW);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, HIGH);
    digitalWrite(B2_bar, LOW);
 }
 if (j == 7){
    digitalWrite(A1, HIGH);
    digitalWrite(A1_bar, LOW);
    digitalWrite(B1, LOW);
    digitalWrite(B1_bar, HIGH);
    digitalWrite(A2, HIGH);
    digitalWrite(A2_bar, LOW);
    digitalWrite(B2, LOW);
    digitalWrite(B2_bar, LOW);
 }
 if (j == 8){
 a = a-1;
 b = b+1;
  j = 0;
  
 }
 }
}
/*
*/
